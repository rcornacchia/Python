#!/bin/bash

osascript -e 'tell app "Terminal"
    do script with command "clear" in window 2
    do script with command "clear" in window 3
    do script with command "clear" in window 4
end tell'

clear
